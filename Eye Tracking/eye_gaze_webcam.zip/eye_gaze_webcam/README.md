# Webcam Eye Gaze Detector

A Python desktop program that watches your laptop webcam and shows **FAR LEFT**, **CENTER**, or **FAR RIGHT**. Uses MediaPipe Face Landmarker iris landmarks and OpenCV. The preview is mirrored so directions are *your* left and right.

## Setup

Install Python 3.11 or newer (64-bit), then open a terminal in this folder.

On Windows (PowerShell):

```powershell
py -m pip install -r requirements.txt
py eye_gaze.py
```

On macOS/Linux:

```bash
python3 -m pip install -r requirements.txt
python3 eye_gaze.py
```

On the first run, the script downloads Google's official `face_landmarker.task` model from:

https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/latest/face_landmarker.task

The model is saved next to the script, so an internet connection is unnecessary on subsequent runs. If the automatic download fails, manually save the model URL above as `face_landmarker.task` beside `eye_gaze.py`.

## Controls

1. Position your face in the webcam image, with steady lighting and your head facing the screen.
2. Look straight forward for about 1 second and press **C**.
3. Look as far **left** as comfortably possible for about 1 second and press **L**.
4. Look as far **right** as comfortably possible for about 1 second and press **R**.
5. The display will classify gaze as FAR LEFT, CENTER or FAR RIGHT. It prints each change to the terminal too.

**X** resets calibration. **Q** or **Esc** quits. If you have multiple webcams, try `py eye_gaze.py --camera 1` on Windows (or `python3 eye_gaze.py --camera 1` elsewhere).

Before calibration is completed, the program uses approximate default thresholds. Three-point calibration is recommended for accuracy.

## How it works

The program finds the approximate horizontal center of each iris, compares that position to its eye corners, averages the two eyes, and applies median smoothing. After calibration, a FAR direction is triggered after 65% of the movement between your center gaze and your calibrated extreme gaze.

The system provides a **rough 3-way classification**, not accurate screen-coordinate or precise point-of-gaze tracking. Glasses, glare, eyelids, head rotation, and weak lighting can affect it. For best results keep your head relatively still and recalibrate whenever the camera/face position changes.

No camera frames are saved or uploaded. The script only downloads the public inference model once from Google and runs camera inference locally.

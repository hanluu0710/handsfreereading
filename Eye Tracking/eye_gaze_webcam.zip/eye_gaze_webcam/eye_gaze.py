"""Classify webcam eye gaze as FAR LEFT, CENTER, or FAR RIGHT.

Uses OpenCV + MediaPipe Face Landmarker (Tasks API). No video is saved or sent.
On first run, downloads the public Face Landmarker model from Google.

Controls while the webcam window is focused:
    C - calibrate while looking straight ahead
    L - calibrate while looking as far left as comfortably possible
    R - calibrate while looking as far right as comfortably possible
    X - clear calibration
    Q or Esc - quit

The webcam image is mirrored so LEFT / RIGHT correspond to YOUR directions.
"""

import argparse
from collections import deque
from pathlib import Path
import statistics
import sys
import time
from urllib.request import urlopen

import cv2
import mediapipe as mp

MODEL_URL = (
    "https://storage.googleapis.com/mediapipe-models/"
    "face_landmarker/face_landmarker/float16/latest/face_landmarker.task"
)
MODEL_PATH = Path(__file__).resolve().parent / "face_landmarker.task"

# Eye corners and corresponding iris centers from MediaPipe's 478 landmarks.
# Each pair of corners is sorted horizontally, so this also works on a
# mirrored camera image.
EYES = (
    (33, 133, 468, 159, 145),
    (362, 263, 473, 386, 374),
)

# A gaze is classified as FAR LEFT or FAR RIGHT after it travels this
# fraction of the calibrated distance from center to the chosen extreme.
FAR_FRACTION = 0.65

# Rough initial classification before calibration, assuming centered ~0.5.
DEFAULT_LEFT_BOUNDARY = 0.40
DEFAULT_RIGHT_BOUNDARY = 0.60


def download_model_if_needed():
    if MODEL_PATH.is_file() and MODEL_PATH.stat().st_size > 100_000:
        return

    print("Downloading the MediaPipe Face Landmarker model (first run only)...")
    temp_path = MODEL_PATH.with_suffix(".task.part")
    try:
        with urlopen(MODEL_URL, timeout=45) as response, open(temp_path, "wb") as output:
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                output.write(block)
        if temp_path.stat().st_size < 100_000:
            raise RuntimeError("The downloaded model was unexpectedly small.")
        temp_path.replace(MODEL_PATH)
    except Exception as exc:
        temp_path.unlink(missing_ok=True)
        raise RuntimeError(
            "Could not download the official face model. Make sure you are "
            f"connected to the internet and retry. Details: {exc}"
        ) from exc


def get_gaze_ratio(landmarks, image_width, image_height):
    """Return relative horizontal iris position (left=0, right=1), or None."""
    if len(landmarks) < 478:
        return None, []

    ratios = []
    pupil_pixels = []

    for corner_a, corner_b, iris_idx, eyelid_top, eyelid_bottom in EYES:
        a, b = landmarks[corner_a], landmarks[corner_b]
        iris = landmarks[iris_idx]
        left = min(a.x, b.x)
        right = max(a.x, b.x)
        eye_width = right - left
        if eye_width < 0.00001:
            continue

        # Ignore eyes that are nearly closed (blink filtering).
        opening = abs(landmarks[eyelid_top].y - landmarks[eyelid_bottom].y)
        if opening / eye_width < 0.07:
            continue

        ratio = (iris.x - left) / eye_width
        ratios.append(ratio)
        pupil_pixels.append(
            (int(iris.x * image_width), int(iris.y * image_height))
        )

    if not ratios:
        return None, []
    return sum(ratios) / len(ratios), pupil_pixels


def get_boundaries(calibration):
    """Return (left threshold, right threshold, valid 3-point calibration)."""
    if all(direction in calibration for direction in ("CENTER", "LEFT", "RIGHT")):
        center = calibration["CENTER"]
        left = calibration["LEFT"]
        right = calibration["RIGHT"]
        if left < center - 0.035 and right > center + 0.035:
            return (
                center - FAR_FRACTION * (center - left),
                center + FAR_FRACTION * (right - center),
                True,
            )

    return DEFAULT_LEFT_BOUNDARY, DEFAULT_RIGHT_BOUNDARY, False


def classify(ratio, calibration):
    left_limit, right_limit, _ = get_boundaries(calibration)
    if ratio < left_limit:
        return "FAR LEFT"
    if ratio > right_limit:
        return "FAR RIGHT"
    return "CENTER"


def draw_ui(frame, label, ratio, calibration, note):
    width = frame.shape[1]
    height = frame.shape[0]
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (width, 150), (20, 20, 20), -1)
    cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)

    colors = {
        "FAR LEFT": (50, 210, 255),
        "CENTER": (75, 230, 100),
        "FAR RIGHT": (220, 120, 255),
        "NO FACE / EYES": (220, 220, 220),
    }
    cv2.putText(
        frame, label, (18, 43), cv2.FONT_HERSHEY_SIMPLEX,
        1.05, colors.get(label, (255, 255, 255)), 3, cv2.LINE_AA,
    )

    _, _, calibrated = get_boundaries(calibration)
    if calibrated:
        line = "Calibrated | C: center  L: left  R: right  X: reset"
    else:
        collected = ", ".join(k for k in ("CENTER", "LEFT", "RIGHT") if k in calibration)
        line = "Calibrate: look center/C, far left/L, far right/R"
        if collected:
            line += "  [" + collected + "]"
    cv2.putText(frame, line, (18, 79), cv2.FONT_HERSHEY_SIMPLEX, 0.49,
                (240, 240, 240), 1, cv2.LINE_AA)
    cv2.putText(frame, "Hold each gaze ~1 second, then press its key. Q: quit",
                (18, 105), cv2.FONT_HERSHEY_SIMPLEX, 0.49,
                (240, 240, 240), 1, cv2.LINE_AA)

    if ratio is not None:
        left, right, _ = get_boundaries(calibration)
        debug = f"Iris position: {ratio:.3f}     boundaries: {left:.3f} / {right:.3f}"
        cv2.putText(frame, debug, (18, 132), cv2.FONT_HERSHEY_SIMPLEX,
                    0.48, (225, 225, 225), 1, cv2.LINE_AA)
    if note:
        cv2.rectangle(frame, (0, height - 42), (width, height), (30, 30, 30), -1)
        cv2.putText(frame, note, (14, height - 15), cv2.FONT_HERSHEY_SIMPLEX,
                    0.58, (230, 230, 255), 2, cv2.LINE_AA)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--camera", type=int, default=0,
                        help="webcam index (default: 0; try 1 for another camera)")
    args = parser.parse_args()

    download_model_if_needed()

    # On Windows, DirectShow generally offers reliable webcam startup.
    if sys.platform.startswith("win"):
        cap = cv2.VideoCapture(args.camera, cv2.CAP_DSHOW)
        if not cap.isOpened():
            cap.release()
            cap = cv2.VideoCapture(args.camera)
    else:
        cap = cv2.VideoCapture(args.camera)
    if not cap.isOpened():
        raise RuntimeError("Cannot open the webcam. Check permissions or try --camera 1.")

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    options = mp.tasks.vision.FaceLandmarkerOptions(
        base_options=mp.tasks.BaseOptions(model_asset_path=str(MODEL_PATH)),
        running_mode=mp.tasks.vision.RunningMode.VIDEO,
        num_faces=1,
        min_face_detection_confidence=0.5,
        min_face_presence_confidence=0.5,
        min_tracking_confidence=0.5,
    )

    samples = deque(maxlen=9)
    calibration = {}
    last_label = None
    note = ""
    note_expires = 0.0
    previous_timestamp_ms = -1

    try:
        with mp.tasks.vision.FaceLandmarker.create_from_options(options) as landmarker:
            while True:
                success, frame = cap.read()
                if not success:
                    print("Unable to read a webcam frame.", file=sys.stderr)
                    break

                frame = cv2.flip(frame, 1)  # Mirror so user-right is image-right.
                height, width = frame.shape[:2]
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)

                timestamp_ms = max(int(time.monotonic() * 1000), previous_timestamp_ms + 1)
                previous_timestamp_ms = timestamp_ms
                result = landmarker.detect_for_video(mp_image, timestamp_ms)

                ratio = None
                pupil_pixels = []
                if result.face_landmarks:
                    ratio, pupil_pixels = get_gaze_ratio(
                        result.face_landmarks[0], width, height
                    )

                if ratio is None:
                    label = "NO FACE / EYES"
                    samples.clear()
                else:
                    samples.append(ratio)
                    ratio = statistics.median(samples)  # Reduce flickering.
                    label = classify(ratio, calibration)
                    for x, y in pupil_pixels:
                        cv2.circle(frame, (x, y), 5, (0, 255, 255), -1)
                        cv2.circle(frame, (x, y), 8, (0, 0, 0), 1)

                if label != last_label:
                    print(label, flush=True)  # Useful when connecting to other programs.
                    last_label = label

                if time.monotonic() > note_expires:
                    note = ""
                draw_ui(frame, label, ratio, calibration, note)
                cv2.imshow("Webcam Eye Gaze - C / L / R to calibrate", frame)

                key = cv2.waitKey(1) & 0xFF
                if key in (ord("q"), 27):
                    break
                if key == ord("x"):
                    calibration.clear()
                    note = "Calibration cleared."
                    note_expires = time.monotonic() + 2
                elif key in (ord("c"), ord("l"), ord("r")):
                    direction = {ord("c"): "CENTER", ord("l"): "LEFT", ord("r"): "RIGHT"}[key]
                    if len(samples) >= 4:
                        calibration[direction] = statistics.median(samples)
                        note = f"Saved {direction} at {calibration[direction]:.3f}"
                        if len(calibration) == 3 and not get_boundaries(calibration)[2]:
                            note = "Calibration inconsistent. Keep head still and redo C / L / R."
                        print(note)
                    else:
                        note = "Keep your eyes visible, then try that key again."
                    note_expires = time.monotonic() + 3
    finally:
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError) as error:
        print(f"Error: {error}", file=sys.stderr)
        sys.exit(1)
